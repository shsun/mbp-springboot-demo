

sudo route add -net 192.0.0.0/8 gw 192.2.113.254 dev enp1s0;

sudo route add -net 10.0.0.0/8 gw 192.2.113.254 dev enp1s0;

sudo route add -net 172.0.0.0/8 gw 192.2.113.254 dev enp1s0;



